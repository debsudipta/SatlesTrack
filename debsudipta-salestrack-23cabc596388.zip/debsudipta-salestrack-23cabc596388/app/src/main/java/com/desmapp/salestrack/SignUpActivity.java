package com.desmapp.salestrack;

import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.loopj.android.http.*;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class SignUpActivity extends AppCompatActivity {

    EditText edtFirst, edtMiddle, edtLast, edtPhone, edtEmail, edtAddress, edtPassword, edtConfirmPassword;

    Button btnSubmit;

    String firstName, middleName, lastName, phone, email, address, password, confirmPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

       /* Intent intent = getIntent();
        String  url = intent.getStringExtra("URL");*/

        edtFirst = findViewById(R.id.editTextFirst);
        edtMiddle = findViewById(R.id.editTextMiddle);
        edtLast = findViewById(R.id.editTextLast);
        edtPhone = findViewById(R.id.editTextPhone);
        edtEmail = findViewById(R.id.editTextEmail);
        edtAddress = findViewById(R.id.editTextAddress);
        edtPassword = findViewById(R.id.editTextPassword);
        edtConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        btnSubmit = findViewById(R.id.buttonSubmit);

        firstName = middleName = lastName = phone = email = address = password = confirmPassword = "";

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveUser(ConfigSales.url);
            }
        });
    }

    void saveUser(String url){
        firstName = edtFirst.getText().toString().trim();
        middleName = edtMiddle.getText().toString().trim();
        lastName = edtLast.getText().toString().trim();
        phone = edtPhone.getText().toString().trim();
        email = edtEmail.getText().toString().trim();
        address = edtAddress.getText().toString().trim();
        password = edtPassword.getText().toString().trim();
        confirmPassword = edtConfirmPassword.getText().toString().trim();
        String name;
        String encryptedPassword;

        if(middleName != null)
            name = firstName + " " + middleName + " "+ lastName;
        else
            name = firstName + " " + lastName;

        //Validation
        if(firstName.isEmpty()){
            edtFirst.setError("Required!");
            edtFirst.requestFocus();
            return;
        }

        if(lastName.isEmpty()){
            edtLast.setError("Required!");
            edtLast.requestFocus();
            return;
        }

        if(phone.isEmpty()){
            edtPhone.setError("Required!");
            edtPhone.requestFocus();
            return;
        }

        if(email.isEmpty()){
            edtEmail.setError("Required!");
            edtEmail.requestFocus();
            return;
        }

        if(address.isEmpty()){
            edtAddress.setError("Required!");
            edtAddress.requestFocus();
            return;
        }

        if(password.isEmpty()){
            edtPassword.setError("Required!");
            edtPassword.requestFocus();
            return;
        }

        if(confirmPassword.isEmpty()){
            edtConfirmPassword.setError("Required!");
            edtConfirmPassword.requestFocus();
            return;
        }

        if(!password.equals(confirmPassword)){
            Toast.makeText(this, "Passwords mismatch!!!", Toast.LENGTH_SHORT).show();
            edtPassword.setText("");
            edtConfirmPassword.setText("");
            edtPassword.requestFocus();
            return;
        }

        encryptedPassword = Base64.encodeToString(password.getBytes(), Base64.DEFAULT);


        try {
            AsyncHttpClient client = new AsyncHttpClient();
            client.setConnectTimeout(40000);
            // Http Request Params Object
            RequestParams params = new RequestParams();

            params.put("NAME", name);
            params.put("PHONE", phone);
            params.put("EMAIL", email);
            params.put("ADDRESS", address);
            params.put("PWD", encryptedPassword);

            Log.e("url",ConfigSales.url);

            client.post(  ConfigSales.url + "/sign_up.php", params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                    String jsonStr = new String(responseBody);

                    Log.e("Info=" ,"Response from server: " + jsonStr);

                    if (jsonStr != null) {

                       String status = null;
                       String msg = null;

                       try {
                           JSONObject jsonObj = new JSONObject(jsonStr);

                           // Getting JSON Array node

                            //status = jsonObj.getString("status");
                            msg = jsonObj.getString("msg");

                       }
                       catch (final JSONException e) {
                           Log.e("Info:", "Json parsing error: " + e.getMessage());
                       }
                       Toast.makeText(SignUpActivity.this, msg, Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(SignUpActivity.this, AdminHomeActivity.class);
                        startActivity(intent);
                        finish();
                   }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Toast.makeText(SignUpActivity.this, "Network Failure!!!!!"+ statusCode, Toast.LENGTH_SHORT).show();

                }


            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}