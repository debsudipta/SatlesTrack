package com.desmapp.salestrack;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

import cz.msebera.android.httpclient.Header;

public class FormSubmitActivity extends AppCompatActivity implements LocationListener {

    int uID = 0;
    String name = "";

    ImageView imageView;
    EditText edtOrgName, edtOrgBranch, edtPersonName, edtPhone, edtBusinessValue, edtRemarks;
    Button btnCapture, btnSubmit;

    Bitmap bitmap;

    LocationManager locationManager;

    boolean isImageCaptured = false;

    static final int REQUEST_IMAGE_CAPTURE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_submit);

        locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);

        Bundle extras = getIntent().getExtras();
        uID = extras.getInt("UID");
        name = extras.getString("NAME");

        Log.e("UID(Form):", String.valueOf(uID));
        Log.e("Name(Form):", name);

        imageView = findViewById(R.id.imageViewSelfie);

        edtOrgName = findViewById(R.id.editTextOrgName);
        edtOrgBranch = findViewById(R.id.editTextOrgBranch);
        edtPersonName = findViewById(R.id.editTextContactPersonName);
        edtPhone = findViewById(R.id.editTextContactPhone);
        edtBusinessValue = findViewById(R.id.editTextBusinessValue);
        edtRemarks = findViewById(R.id.editTextRemarks);
       // edtUrl = findViewById(R.id.editUrl);

        btnCapture = findViewById(R.id.buttonCap);
        btnSubmit = findViewById(R.id.buttonSubmitForm);

     //   edtUrl.setText(ConfigSales.url.toString());


        if (!hasCamera())
            btnCapture.setEnabled(false);

        btnCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);

                //Clears the cache everytime when Capture button is clicked
                //imageView.setImageBitmap(null);
                imageView.destroyDrawingCache();
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                upload();
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();

        if(!SharedPrefManager.getInstance(getApplicationContext()).isSignedIn()){
            stopService(new Intent(FormSubmitActivity.this, BackgroundService.class));
            Intent intent = new Intent(FormSubmitActivity.this, MainActivity.class);
            startActivity(intent);
            finish();

        }

        if (isImageCaptured) {
            btnSubmit.setEnabled(true);
        }

    }

    private void upload() {
        String orgName = edtOrgName.getText().toString().trim();
        String orgBranch = edtOrgBranch.getText().toString().trim();
        String personName = edtPersonName.getText().toString().trim();
        String personPhone = edtPhone.getText().toString().trim();
        String businessValue = edtBusinessValue.getText().toString().trim();
        String remarks = edtRemarks.getText().toString().trim();

        if (ContextCompat.checkSelfPermission(FormSubmitActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(FormSubmitActivity.this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast toast=Toast. makeText(getApplicationContext(),"Please Grant Permission for Location Access...",Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        if(! LocationManagerCompat.isLocationEnabled(locationManager)){
            Toast toast=Toast. makeText(getApplicationContext(),"Please Enable Your Location...",Toast.LENGTH_SHORT);
            toast.show();
            return;
        }

        String gps_location = getLocation();

        // Validation

       /* if (imageView.getDrawable() == null) {
            imageView.requestFocus();
            Toast.makeText(FormSubmitActivity.this, "Image Required!!!", Toast.LENGTH_SHORT).show();
            return;
        }*/

        if (orgName.isEmpty()) {
            edtOrgName.setError("Required!!!");
            edtOrgName.requestFocus();
            return;
        }

        if (orgBranch.isEmpty()) {
            edtOrgBranch.setError("Required!!!");
            edtOrgBranch.requestFocus();
            return;
        }

        if (personName.isEmpty()) {
            edtPersonName.setError("Required!!!");
            edtPersonName.requestFocus();
            return;
        }

        if (personPhone.isEmpty()) {
            edtPhone.setError("Required!!!");
            edtPhone.requestFocus();
            return;
        }

        if (businessValue.isEmpty()) {
            edtBusinessValue.setError("Required!!!");
            edtBusinessValue.requestFocus();
            return;
        }

        if (remarks.isEmpty()) {
            edtRemarks.setError("Required!!!");
            edtRemarks.requestFocus();
            return;
        }

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] imageInByte = byteArrayOutputStream.toByteArray();
        String encodedImage = Base64.encodeToString(imageInByte, Base64.DEFAULT);

        if (ContextCompat.checkSelfPermission(FormSubmitActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(FormSubmitActivity.this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            }, 100);
        }


        try {
            AsyncHttpClient client = new AsyncHttpClient();
            client.setConnectTimeout(40000);
            // Http Request Params Object
            RequestParams params = new RequestParams();

            params.put("EN_IMAGE", encodedImage);
            params.put("ORG_NAME", orgName);
            params.put("ORG_BRANCH", orgBranch);
            params.put("PERSON_NAME", personName);
            params.put("PERSON_PHONE", personPhone);
            params.put("BUSINESS_VALUE", businessValue);
            params.put("REMARKS", remarks);
            params.put("LOCATION", gps_location);
            params.put("UID", uID);
         //   params.put("NAME", name);
            params.put("TOKEN", ConfigSales.Token);

            client.post(ConfigSales.url + "/submit_form.php", params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                    String jsonStr = new String(responseBody);

                    Log.e("Info=", "Response from server: " + jsonStr);

                    if (jsonStr != null) {

                        String status = null;
                        String msg = null;

                        try {
                            JSONObject jsonObj = new JSONObject(jsonStr);

                            // Getting JSON Array node

                            //status = jsonObj.getString("status");
                            msg = jsonObj.getString("msg");

                        } catch (final JSONException e) {
                            Log.e("Info:", "Json parsing error: " + e.getMessage());
                        }
                        Toast.makeText(FormSubmitActivity.this, msg, Toast.LENGTH_SHORT).show();

                        imageView.destroyDrawingCache();
                        imageView.setImageDrawable(getResources().getDrawable(R.drawable.ic_menu_camera));

                        edtOrgName.setText("");
                        edtOrgBranch.setText("");
                        edtPersonName.setText("");
                        edtPhone.setText("");
                        edtBusinessValue.setText("");
                        edtRemarks.setText("");

                        isImageCaptured = false;
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Toast.makeText(FormSubmitActivity.this, "Network Failure!!!!!", Toast.LENGTH_SHORT).show();

                }


            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean hasCamera() {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }

    private String getLocation() {

        String location = null;

        try {

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return "Err";
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, (LocationListener) FormSubmitActivity.this);
            Location oldLoc;

            oldLoc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (oldLoc == null){
                Toast toast=Toast. makeText(getApplicationContext(),"Location value is not updated !!! Login after sometime",
                        Toast.LENGTH_LONG);
                toast.show();
            }


           /* Toast toast=Toast. makeText(getApplicationContext(),"Location."+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude()+","+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude(),Toast.LENGTH_LONG);
            toast.show();*/

            double latitude = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude();
            double longitude = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude();

            location = String.valueOf(latitude) + "," + String.valueOf(longitude);
            return location;

        }
        catch (Exception e){
            return "error!";
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK && data != null) {
            Bundle extras = data.getExtras();
            bitmap = (Bitmap) extras.get("data");
            imageView.setImageBitmap(bitmap);
            isImageCaptured = true;
        }
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }

    public void profile(View view) {
        Intent intent = new Intent(view.getContext(), ProfileActivity.class);
        startActivity(intent);
    }
}