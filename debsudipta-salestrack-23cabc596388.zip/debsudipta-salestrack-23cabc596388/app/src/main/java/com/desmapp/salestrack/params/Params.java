package com.desmapp.salestrack.params;

public class Params {

    public static final int DB_VERSION = 1;
    public static final String DB_NAME = "entry_db";
    public static final String TABLE_NAME = "url_table";

    //Keys

    public static final String KEY_ID = "id";
    public static final String KEY_URL = "url";

}
