package com.desmapp.salestrack;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.desmapp.salestrack.data.DBHandler;
import com.desmapp.salestrack.model.URL;

public class SettingsActivity extends AppCompatActivity {

    TextView txtServerUrlView;
    EditText edtServerUrl, edtSettingsPwd, edtConfirmSettingPwd;
    Button btnUpdate;
    public static final String pwd = "87654321";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        txtServerUrlView = findViewById(R.id.textViewServerUrl);
        edtServerUrl = findViewById(R.id.editTextServerUrl);
        edtSettingsPwd = findViewById(R.id.editTextSettingsPassword);
        edtConfirmSettingPwd = findViewById(R.id.editTextConfirmSettingsPassword);
        btnUpdate = findViewById(R.id.buttonUpdate);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String serverUrl = edtServerUrl.getText().toString().trim();
                String settingsPwd = edtSettingsPwd.getText().toString().trim();
                String confirmSettingsPwd = edtConfirmSettingPwd.getText().toString().trim();

                if(!settingsPwd.equals(confirmSettingsPwd) || !settingsPwd.equals(pwd)){
                    Toast.makeText(SettingsActivity.this, "Passwords Mismatch or Invalid Settings Password!!!", Toast.LENGTH_SHORT).show();
                    edtSettingsPwd.setText("");
                    edtConfirmSettingPwd.setText("");
                    edtSettingsPwd.requestFocus();
                    return;
                }

               /* addServerURL(serverUrl);

                String urlSaved = getUrlFromDb();

                txtServerUrlView.setText(urlSaved); */

                SharedPreferences sharedPreferences = getSharedPreferences("saver", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("url", serverUrl);
                editor.apply();
                txtServerUrlView.setText(serverUrl);

                edtServerUrl.setText("");
                edtSettingsPwd.setText("");
                edtConfirmSettingPwd.setText("");
            }
        });

        // Get the url back from device
        SharedPreferences getShared = getSharedPreferences("saver", MODE_PRIVATE);
        String value = getShared.getString("url", "http://api.amcore.in/");
        edtServerUrl.setText(value);
     //   txtServerUrlView.setText(value);
    }

   /* private String getUrlFromDb() {

        DBHandler db = new DBHandler(SettingsActivity.this);

        URL urlFromDb = db.getServerUrl();
        Toast.makeText(this, "URL updated successfully...", Toast.LENGTH_SHORT).show();
        return urlFromDb.getUrl();
    }

    private void addServerURL(String serverUrl) {

        Log.i("Info: addServerUrl() :", serverUrl);

        DBHandler db = new DBHandler(SettingsActivity.this);
        db.addUrl(serverUrl);
    }*/
}