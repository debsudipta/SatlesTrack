package com.desmapp.salestrack;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import android.content.*;
import android.os.*;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class BackgroundService extends Service implements LocationListener {


    public Context context = this;
    public Handler handler = null;
    Runnable runnable = null;

    String location = "";
    String time = "";
    LocationManager locationManager;

    @Override
    public void onCreate() {

        Log.e("Info(BG):", "Service created...");
        time = ConfigSales.getCurrentTime();
        Log.e("Time:", time);


        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {

                time = ConfigSales.getCurrentTime();
                Log.e("Time:", time);

                if((ConfigSales.currentHour == 23 && ConfigSales.currentMin == 59)
                        || (ConfigSales.currentHour == 0 && ConfigSales.currentMin == 0)){
                    SharedPrefManager.getInstance(getApplicationContext()).signOut();
                    Log.e("BG:Info=", "Signed Out at 00:00");
                }

             //   Toast.makeText(context, ConfigSales.getCurrentTime(), Toast.LENGTH_SHORT).show();

                location = getLocation();
                Log.e("BG:Location=", location);
                updateLocation(location);

                handler.postDelayed(runnable, 1800000);    //Repeats run() periodically after mentioned time in milliseconds
            }
        };

        handler.postDelayed(runnable, ConfigSales.modTime * 1000);     //Starts the service after mentioned milliseconds for 1st time
    }

    private String getLocation() {

        try {
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);

            //Log.e("getLocation: ","error" );
            if (ContextCompat.checkSelfPermission(BackgroundService.this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(BackgroundService.this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast toast=Toast. makeText(getApplicationContext(),"Please Enable Location.",Toast.LENGTH_LONG);
                toast.show();
                return "Err1";
            }
            if(! LocationManagerCompat.isLocationEnabled(locationManager)){
                Toast toast=Toast. makeText(getApplicationContext(),"Please Enable your Location.",Toast.LENGTH_LONG);
                toast.show();
                return "Err2";
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, (LocationListener) BackgroundService.this);

            Location oldLoc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            if (oldLoc == null){
                Toast toast=Toast. makeText(getApplicationContext(),"Location value is not updated!!! Sign In after sometime...",
                        Toast.LENGTH_LONG);
                toast.show();
            }


           /* Toast toast=Toast. makeText(getApplicationContext(),"Location."+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude()+","+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude(),Toast.LENGTH_LONG);
            toast.show();*/

            return locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude()+","+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude();
        }catch (Exception e){
            return "Err3"+e.toString();
        }


       /* Log.e("Location from getLoc():", location);
        return location;*/

    }

    private void updateLocation(String location) {

        try {
            AsyncHttpClient client = new AsyncHttpClient();
            client.setConnectTimeout(40000);
            // Http Request Params Object
            RequestParams params = new RequestParams();

            params.put("USERID", ConfigSales.UserId);
            params.put("GPSLOCATION", location);
            Log.e("Location:", location);

            //params.put("uph", MobileNo.toString());
            //  params.put("uph", mob.toString());
            client.post( ConfigSales.url + "/trackLocation.php", params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                    String jsonStr = new String(responseBody);

                    Log.e("Info" ,"Response from url: " + jsonStr);

                    if (jsonStr != null) {

                        //boolean status = false;
                        String msg = null;
                        int userID = 0;
                        String name = "";

                        try {
                            JSONObject jsonObj = new JSONObject(jsonStr);

                            // Getting JSON Array node

                            // status = jsonObj.getBoolean("status");
                            msg = jsonObj.getString("msg");

                            Log.e("msg:", msg);

                        }
                        catch (final JSONException e) {
                            Log.e("Info:", "Json parsing error: " + e.getMessage());
                        }

                        if(msg.equals("success"))
                        {
                            Log.e("Info(Config):", "Location Updated...");
                        }

                        else if(msg.equals("exists")){
                            Log.e("Info(Config):", "Multiple user with same credentials exist!!!");
                        }

                        else{
                            Log.e("Info(Config):", "Location Update failed!!!");
                        }
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Toast.makeText(BackgroundService.this, "Network Failure!!!"+ statusCode, Toast.LENGTH_SHORT).show();

                }


            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onDestroy() {
        /* IF YOU WANT THIS SERVICE KILLED WITH THE APP THEN UNCOMMENT THE FOLLOWING LINE */
        handler.removeCallbacks(runnable);
        Log.e("Info:BG=", "Service Stopped!!!");

    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }
}
