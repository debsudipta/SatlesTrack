package com.desmapp.salestrack.model;

public class URL {

    private int id;
    private String url;

    public URL(String url) {
        this.url = url;
    }

    public URL() {

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
