package com.desmapp.salestrack;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;

import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import cz.msebera.android.httpclient.Header;

public class SalesmanSignInActivity extends AppCompatActivity implements LocationListener {

    EditText edtUsername, edtPassword;
    Button btnSignIn;
    LocationManager locationManager;
    double latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salesman_sign_in);

       /* Intent intent = getIntent();
        String  url = intent.getStringExtra("URL");*/


        edtUsername = findViewById(R.id.editTextEmailAddress);
        edtPassword = findViewById(R.id.editTextPassword);

        btnSignIn = findViewById(R.id.buttonSignIn);


        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn(ConfigSales.url);
            }
        });
    }

    private void signIn(String url) {

        if (ContextCompat.checkSelfPermission(SalesmanSignInActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(SalesmanSignInActivity.this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast toast=Toast. makeText(getApplicationContext(),"Please Enable Location.",Toast.LENGTH_LONG);
            toast.show();
            return;
        }
        if(! LocationManagerCompat.isLocationEnabled(locationManager)){
            Toast toast=Toast. makeText(getApplicationContext(),"Please Enable your Location.",Toast.LENGTH_LONG);
            toast.show();
            return;
        }

        String username = edtUsername.getText().toString().trim();
        String password = edtPassword.getText().toString().trim();

        String gps_location = getLocation();

        String signInAddress = getCompleteAddressString(latitude, longitude);


        if(username.isEmpty()){
            edtUsername.setError("Required!");
            edtUsername.requestFocus();
            return;
        }

        if(password.isEmpty()){
            edtPassword.setError("Required!");
            edtPassword.requestFocus();
            return;
        }

        String encodedPassword = Base64.encodeToString(password.getBytes(), Base64.DEFAULT);

        try {
            AsyncHttpClient client = new AsyncHttpClient();
            client.setConnectTimeout(40000);
            // Http Request Params Object
            RequestParams params = new RequestParams();

            params.put("USERNAME", username);
            params.put("PWD", encodedPassword);
            params.put("LOCATION", gps_location);
            params.put("ADDRESS", signInAddress);
            Log.e("Location(SignIn):", gps_location);
            Log.e("SignIn:Address=", signInAddress);
            Log.e("url(SignIn)",ConfigSales.url);

            //params.put("uph", MobileNo.toString());
            //  params.put("uph", mob.toString());
            client.post( ConfigSales.url + "/sign_in.php", params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                    String jsonStr = new String(responseBody);

                    Log.e("Info" ,"Response from url: " + jsonStr);

                    if (jsonStr != null) {

                        //boolean status = false;
                        String msg = null;
                        int userID = 0;
                        int userType = 0;
                        String name = "";
                        String token = "";

                        try {
                            JSONObject jsonObj = new JSONObject(jsonStr);

                            // Getting JSON Array node

                           // status = jsonObj.getBoolean("status");
                            msg = jsonObj.getString("msg");
                            userID = jsonObj.getInt("UID");
                            userType = jsonObj.getInt("UTYPE");
                            name = jsonObj.getString("name");
                            token = jsonObj.getString("Token");

                            Log.e("SignIn:UID=", String.valueOf(userID));
                            Log.e("SignIn:Name=", name);

                        }
                        catch (final JSONException e) {
                            Log.e("Info:", "Json parsing error: " + e.getMessage());
                        }

                        if(msg.equals("success") && userType == 0)
                        {
                            Toast.makeText(SalesmanSignInActivity.this, "Sign In successful...", Toast.LENGTH_SHORT).show();

                            ConfigSales.name = name;
                            ConfigSales.UserId = userID;
                            ConfigSales.Token = token;
                           // ConfigSales.isSignOut = false;

                            SharedPrefManager.getInstance(getApplicationContext()).userSignIn(userID);

                            startService(new Intent(SalesmanSignInActivity.this, BackgroundService.class));

                            Intent intent = new Intent(SalesmanSignInActivity.this, FormSubmitActivity.class);
                            Bundle extras = new Bundle();
                            extras.putInt("UID", userID);
                            extras.putString("NAME", name);
                            intent.putExtras(extras);
                            startActivity(intent);
                            finish();
                        }

                        else if(msg.equals("exists")){
                            Toast.makeText(SalesmanSignInActivity.this, "Multiple user with same credentials exist...", Toast.LENGTH_SHORT).show();
                        }

                        else{
                            Toast.makeText(SalesmanSignInActivity.this, "Invalid Username or Password!!!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Toast.makeText(SalesmanSignInActivity.this, "Network Failure!!!"+ statusCode, Toast.LENGTH_SHORT).show();

                }


            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getLocation() {

        String location = "";

        try {
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);

            //Log.e("getLocation: ","error" );
            if (ContextCompat.checkSelfPermission(SalesmanSignInActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(SalesmanSignInActivity.this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast toast=Toast. makeText(getApplicationContext(),"Please Enable Location.",Toast.LENGTH_LONG);
                toast.show();
                return "Err1";
            }
            if(! LocationManagerCompat.isLocationEnabled(locationManager)){
                Toast toast=Toast. makeText(getApplicationContext(),"Please Enable your Location.",Toast.LENGTH_LONG);
                toast.show();
                return "Err2";
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, (LocationListener) SalesmanSignInActivity.this);

            Location oldLoc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

          /*  if (oldLoc == null){
                Toast toast=Toast. makeText(getApplicationContext(),"Location value is not updated!!! Sign In after sometime...",
                        Toast.LENGTH_LONG);
                toast.show();
            } */


           /* Toast toast=Toast. makeText(getApplicationContext(),"Location."+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude()+","+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude(),Toast.LENGTH_LONG);
            toast.show();*/

         /*  return locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude()+","+
                   locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude();*/

             latitude = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude();
             longitude = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude();

            location = String.valueOf(latitude) + "," + String.valueOf(longitude);
            return location;

        }catch (Exception e){
            return "Err3"+e.toString();
        }


       /* Log.e("Location from getLoc():", location);
        return location;*/
    }

    private String getCompleteAddressString(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
                strAdd = strReturnedAddress.toString();
                Log.w("Address:", strReturnedAddress.toString());
            } else {
                Log.w("Address:", "No Address returned!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.w("Address:", "Cannot get Address!");
        }
        return strAdd;
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}