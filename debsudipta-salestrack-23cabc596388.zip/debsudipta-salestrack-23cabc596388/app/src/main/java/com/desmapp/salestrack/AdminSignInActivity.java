package com.desmapp.salestrack;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class AdminSignInActivity extends AppCompatActivity implements LocationListener {

    EditText edtAdminUserName, edtAdminPwd;
    Button btnAdminSignIn;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_sign_in);

        locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);

        edtAdminUserName = findViewById(R.id.editTextAdminUsername);
        edtAdminPwd = findViewById(R.id.editTextAdminPwd);
        btnAdminSignIn = findViewById(R.id.buttonAdminSignIn);

        btnAdminSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn(ConfigSales.url);
            }
        });

    }

    private void signIn(String url) {

        String username = edtAdminUserName.getText().toString().trim();
        String password = edtAdminPwd.getText().toString().trim();


        String gps_location = getLocation();


        if(username.isEmpty()){
            edtAdminUserName.setError("Required!");
            edtAdminUserName.requestFocus();
            return;
        }

        if(password.isEmpty()){
            edtAdminPwd.setError("Required!");
            edtAdminPwd.requestFocus();
            return;
        }

        String encodedPassword = Base64.encodeToString(password.getBytes(), Base64.DEFAULT);

        try {
            AsyncHttpClient client = new AsyncHttpClient();
            client.setConnectTimeout(40000);
            // Http Request Params Object
            RequestParams params = new RequestParams();

            params.put("USERNAME", username);
            params.put("PWD", encodedPassword);
            params.put("LOCATION", gps_location);
            params.put("ADDRESS", "");
            Log.e("Location:", gps_location);
            Log.e("url",ConfigSales.url);

            //params.put("uph", MobileNo.toString());
            //  params.put("uph", mob.toString());
            client.post( ConfigSales.url + "/sign_in.php", params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                    String jsonStr = new String(responseBody);

                    Log.e("Info" ,"Response from url: " + jsonStr);

                    if (jsonStr != null) {

                        //boolean status = false;
                        String msg = null;
                        int userType = 0;

                        try {
                            JSONObject jsonObj = new JSONObject(jsonStr);

                            // Getting JSON Array node

                            // status = jsonObj.getBoolean("status");
                            msg = jsonObj.getString("msg");
                            userType = jsonObj.getInt("UTYPE");
                            Log.e("Utype:", String.valueOf(userType));

                        }
                        catch (final JSONException e) {
                            Log.e("Info:", "Json parsing error: " + e.getMessage());
                        }

                        if(msg.equals("success") && userType == 1)
                        {
                            Toast.makeText(AdminSignInActivity.this, "Sign In successful...", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(AdminSignInActivity.this, AdminHomeActivity.class);
                            startActivity(intent);
                            finish();
                        }

                        else if(msg.equals("exists")){
                            Toast.makeText(AdminSignInActivity.this, "Multiple user with same credentials exist...", Toast.LENGTH_SHORT).show();
                        }

                        else{
                            Toast.makeText(AdminSignInActivity.this, "Invalid Username or Password!!!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Toast.makeText(AdminSignInActivity.this, "Network Failure!!!"+ statusCode, Toast.LENGTH_SHORT).show();

                }


            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private String getLocation() {
        locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);

            String location = "";

        try {
            //Log.e("getLocation: ","error" );
            if (ContextCompat.checkSelfPermission(AdminSignInActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(AdminSignInActivity.this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast toast=Toast. makeText(getApplicationContext(),"Please Enable Location in setting.",Toast.LENGTH_LONG);
                toast.show();
                return "Err1";
            }
            if(! LocationManagerCompat.isLocationEnabled(locationManager)){
                Toast toast=Toast. makeText(getApplicationContext(),"Please Enable your Location.",Toast.LENGTH_LONG);
                toast.show();
                return "Err2";
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, (LocationListener) AdminSignInActivity.this);

            Location oldLoc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            if (oldLoc == null){
                Toast toast=Toast. makeText(getApplicationContext(),"Location value is not updated!!! Sign In after sometime...",
                        Toast.LENGTH_LONG);
                toast.show();
            }


          /*  Toast toast=Toast. makeText(getApplicationContext(),"Location: "+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude()+","+
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude(),Toast.LENGTH_LONG);
            toast.show();*/

            double latitude = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLatitude();
            double longitude = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER).getLongitude();

            location = String.valueOf(latitude) + "," + String.valueOf(longitude);

            return location;

        }catch (Exception e){
            return "Err3"+e.toString();
        }


       /* Log.e("Location from getLoc():", location);
        return location;*/
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }
}