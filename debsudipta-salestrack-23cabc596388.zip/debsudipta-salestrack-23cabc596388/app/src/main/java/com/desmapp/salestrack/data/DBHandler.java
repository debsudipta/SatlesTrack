package com.desmapp.salestrack.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.desmapp.salestrack.model.URL;
import com.desmapp.salestrack.params.Params;

public class DBHandler extends SQLiteOpenHelper {

    public DBHandler(Context context){
        super(context, Params.DB_NAME, null, Params.DB_VERSION);
     //   SQLiteDatabase db=this.getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createQuery = " CREATE TABLE " + Params.TABLE_NAME +
                " ( " + Params.KEY_ID + " INTEGER PRIMARY KEY , "
                + Params.KEY_URL + " TEXT " +
                " ) ";
        Log.d("Info:", createQuery);
        db.execSQL(createQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {


    }

    public void addUrl(String url){

        Log.i("Info- addUrl():", url);

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Params.KEY_URL, url);

        db.insert(Params.TABLE_NAME, null, values);
        Log.d("Info:", "Successfully inserted...");
        db.close();
    }

    public URL getServerUrl(){
        URL url = new URL();
        SQLiteDatabase db = this.getReadableDatabase();

        //Read from db
        String selectQuery = "SELECT * FROM " + Params.TABLE_NAME;
        Cursor cursor = db.rawQuery(selectQuery, null);

        if(cursor.moveToFirst()){
            do{
                url.setId(cursor.getInt(0));
                url.setUrl(cursor.getString(1));
            }
            while (cursor.moveToNext());
        }
        return url;
    }

}
