package com.desmapp.salestrack;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

public class SharedPrefManager {

    static SharedPrefManager spManager;
    Context context;

    public SharedPrefManager(Context context) {
        this.context = context;
    }

    public static synchronized SharedPrefManager getInstance(Context context){
        if(spManager == null)
            spManager = new SharedPrefManager(context);
        return spManager;
    }

    public boolean userSignIn(int id){

        SharedPreferences sharedPreferences = context.getSharedPreferences("user", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt("UserId", id);
        editor.apply();
        return true;
    }

    public boolean isSignedIn(){
        SharedPreferences sharedPreferences = context.getSharedPreferences("user", Context.MODE_PRIVATE);
        Log.e("SPManager: ID=", String.valueOf(sharedPreferences.getInt("UserId", 0)));      //0 is default value
        if(sharedPreferences.getInt("UserId", 0) != 0){
            return true;
        }
        else
            return false;
    }

    public boolean signOut(){

        SharedPreferences sharedPreferences = context.getSharedPreferences("user", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        //ConfigSales.isSignOut = true;

        Intent intent = new Intent(context.getApplicationContext(), BackgroundService.class);
        context.stopService(intent);

       /* Intent intent2 = new Intent(context.getApplicationContext(), MainActivity.class);
        context.startActivity(intent2);*/

        Log.e("SPManager:ID(Sign Out)=", String.valueOf(sharedPreferences.getInt("UserId", 0)));

        return true;
    }

}
