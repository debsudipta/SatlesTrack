package com.desmapp.salestrack;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    TextView txtProfile, txtName, txtNameValue, txtId, txtIdValue;
    Button btnSignOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        txtProfile = findViewById(R.id.textViewProfile);
        txtName = findViewById(R.id.textViewName);
        txtNameValue = findViewById(R.id.textViewNameValue);
        txtId = findViewById(R.id.textViewId);
        txtIdValue = findViewById(R.id.textViewIDValue);
        btnSignOut = findViewById(R.id.buttonSignOut);

        txtNameValue.setText(ConfigSales.name);
        txtIdValue.setText(String.valueOf(ConfigSales.UserId));

        btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPrefManager.getInstance(getApplicationContext()).signOut();
                Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(!SharedPrefManager.getInstance(getApplicationContext()).isSignedIn()){
            stopService(new Intent(ProfileActivity.this, BackgroundService.class));
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }

    }
}