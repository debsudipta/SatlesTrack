package com.desmapp.salestrack;

import android.Manifest;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.icu.text.SimpleDateFormat;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.format.Time;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import cz.msebera.android.httpclient.Header;

public class ConfigSales {
    static String url=null;
    static int UserId= 0;
    static String name = null;
    static String Token=null;
    static int currentHour = 0;
    static int currentMin = 0;
    static int currentSec = 0;
    static int modTime = 0;
    static int modMin = 0;
    static int modSec = 0;
 //   static boolean isSignOut;


    public static String getCurrentTime(){

        TimeZone timeZone = TimeZone.getTimeZone("GMT+05:30");
        Calendar calendar = Calendar.getInstance(timeZone);

        DecimalFormat df = new DecimalFormat("00");

        currentHour = calendar.get(Calendar.HOUR_OF_DAY);
        currentMin = calendar.get(Calendar.MINUTE);
        currentSec = calendar.get(Calendar.SECOND);

        if(currentMin >= 0 && currentMin < 30){
            modSec = 60 - currentSec;
            modMin = 30 - currentMin - 1;
            modTime = modMin * 60 + modSec;
        }
        else{
            modSec = 60 - currentSec;
            modMin = 60 - currentMin - 1;
            modTime = modMin * 60 + modSec;
        }

        String hour = df.format(currentHour);
        String min = df.format(currentMin);
        String sec = df.format(currentSec);

        String time = hour + ":" + min + ":" + sec;

        return time;
    }

}
