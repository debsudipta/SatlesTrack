package com.desmapp.salestrack;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;
import androidx.navigation.NavController;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity implements LocationListener {

    TextView txtUrl;
    Button btnSalesman, btnAdmin;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


     //   edtUrl = findViewById(R.id.editTextUrl);
      //  txtUrl = findViewById(R.id.textViewUrl);

        btnSalesman = findViewById(R.id.buttonSales);
        btnAdmin = findViewById(R.id.buttonAdmin);

        btnSalesman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);

                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                        PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    Toast toast=Toast. makeText(getApplicationContext(),"Please Enable Location. Permission",Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }
                if(! LocationManagerCompat.isLocationEnabled(locationManager)){
                    Toast toast=Toast. makeText(getApplicationContext(),"Please Enable your Location.",Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }

              //  ConfigSales.url = edtUrl.getText().toString().trim();

                Intent intent = new Intent(MainActivity.this, SalesmanSignInActivity.class);
                // intent.putExtra("URL", ConfigSales.url);
                startActivity(intent);
                finish();
            }
        });

        btnAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, AdminSignInActivity.class);
                startActivity(intent);

            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences getShared = getSharedPreferences("saver", MODE_PRIVATE);
        String value = getShared.getString("url", "Default!");
        ConfigSales.url = value;

//        txtUrl.setText(ConfigSales.url);
    }

    public void settings(View view) {

        Intent intent = new Intent(view.getContext(), SettingsActivity.class);
        startActivity(intent);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }
}